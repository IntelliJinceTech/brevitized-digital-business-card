import React from 'react'

export default function Interests() {
    return(
        <div className="interests--container">
            <h2 className="interests--header">Interests</h2>
            <p className="interests--p">
                AI | Data Analytics | Food Consumption Expert | Reader | Professional Internet Searcher | Coffee Lover | Pickeball Amateur
            </p>
        </div>
    )
}